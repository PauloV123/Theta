#include <iostream>
#include <string>
#include <stdlib.h>
#include <sstream>
#include <locale.h>
#include <iterator>
#include <fstream>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	bool exit = false;
	setlocale(LC_ALL, "portuguese-brazilian");
	char entrada[200];
	char entrada2[200];
	int x = 0;
	int i;
	while(!exit){
		cout << "#";
		cin >> entrada;
		istringstream iss(entrada);
		
		do{
        	string subs;
        	iss >> subs;
        	if(subs != "createhd" && subs != ""){
        		string nome;
        		nome = subs;
        		string cmdSystem ="fsutil file createnew " + nome +".txt 32768";
        		
        		cout << nome + " criado com sucesso" << endl;
        		system(cmdSystem.c_str());
        		x = 1;
        		
        		while(x != 2){
        			cout<< "#" + nome + ">";
        			cin >> entrada2;
        			istringstream iss2(entrada2);
				    do
				    {
				        string subs2;
				        iss2 >> subs2;
	
				        if(subs2 != "create" && subs2 != ""){
				        	string nomeArq;
				        	nomeArq = subs2;
				        	string cmdSystem2 = "copy con " + nome + ".txt";
				        	cout << cmdSystem2 << endl;
				        	system(cmdSystem2.c_str());
				        	cout<<endl;
				        	/*ifstream in( "HD1.txt", ifstream::ate | ifstream::binary );
						    long tam = in.tellg();
						    */
				        	cout << "arquivo "+ nomeArq + " criado" << endl;
				        //PROBLEMA COM CARACTER ESPECIAL E PROBLEMA PRA PRINTAR O TAMANHO DO TEXTO
				        	x = 2;
						}
				    } while (iss2);
        			
        			
				}
			}
			
    	} while (iss && x != 1);
    	
		
		if(entrada == "exit"){
			exit = true;
		}
		
	}
	
	return 0;
	system("pause");
}
